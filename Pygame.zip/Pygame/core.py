class Health():
    def __init__(self, max_health, current, hurt_rate):
        self.max_health = max_health
        self.current = current
        self.hurt_rate = hurt_rate

    def hurt(self):
        self.current -= self.hurt_rate
        if self.current < 0:
            self.current = 0

    def heal(self, potion_used):
        self.current += potion_used.enhance_rate
        if self.current > self.max_health:
            self.current = self.max_health

class Stamina():
    def __init__(self, max_stamina, current, regen_rate, drain_rate):
        self.max_stamina = max_stamina
        self.current = current
        self.regen_rate = regen_rate
        self.drain_rate = drain_rate

    def use(self):
        self.current -= self.drain_rate
        if self.current < 0:
            self.current = 0

    def recover(self):
        self.current += self.regen_rate
        if self.current > self.max_stamina:
            self.current = self.max_stamina

    def is_empty(self):
        if self.current <= 0:
            return True
        else:
            return False



class Attack():
    def __init__(self, attack_type, damage):
        self.attack_type = attack_type
        self.damage = damage

    def use(self, attacker, target):
        target.health.current -= self.damage
        if target.health.current < 0:
            target.health.current = 0
