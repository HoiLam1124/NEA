class Potion():
    def __init__(self, name, enhance_rate):
        self.name = name
        self.enhance_rate = enhance_rate


class HealthPotion(Potion):
    def __init__(self):
        super().__init__("Health enhance potion", enhance_rate=3)



class SpeedPotion(Potion):
    def __init__(self):
        super().__init__("Speed enhance potion", enhance_rate=3)

class StaminaPotion(Potion):
    def __init__(self):
        super().__init__("Stamina enhance potion", enhance_rate=3)
