import pygame
from constant import WHITE

def main_menu():
    pygame.display.set_caption("Menu")
    screen = pygame.display.set_mode((1000, 400))

    while True:
        screen.fill(WHITE)

        # learn how to blit images for buttons and background
