
import pygame

<<<<<<< HEAD
from entities import Enemy, Player, Giant
from constant import *
# from ui import *
=======
from classes import Enemy, Player
from classes import WHITE, GREEN, YELLOW, PURPLE, RED, BLACK
from classes import x, y, WIDTH, HEIGHT
>>>>>>> origin/master


def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Lam's Game")
    clock = pygame.time.Clock()

    player = Player()

    # Put all enemies in a list to handle them easily
    enemies = [
        Enemy(),
        Giant(700, 200)  # Ensure your Giant class matches these arguments
    ]

    game_running = True
<<<<<<< HEAD
=======
    game_over = False


    def main_menu():
        pygame.display.set_caption("Menu")
        screen = pygame.display.set_mode((1000, 400))
>>>>>>> origin/master

        while True:
            screen.fill(WHITE)

            # learn how to blit images for buttons and background

    def main_menu(screen):
        running = True

        while running:
            screen.fill(WHITE)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    exit()

            pygame.display.flip()

    main_menu(screen)
    #
    while game_running:
        screen.fill(BLACK)

<<<<<<< HEAD
        # 1. Event Handling
=======
        if player.health.current <= 0:
            game_over = True

        #if enemy.health.current <= 0:


>>>>>>> origin/master
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_running = False

        # 2. Update Logic
        keys = pygame.key.get_pressed()

<<<<<<< HEAD
        # Check if player is dead EVERY frame
        game_over = player.health.current <= 0
=======
        player.sprint(shift_pressed)
        player.handle_attacks(keys, enemy)

>>>>>>> origin/master

        if not game_over:
            # Movement
            shift_pressed = keys[pygame.K_LSHIFT] or keys[pygame.K_RSHIFT]
            player.sprint(shift_pressed)

            dx, dy = 0, 0
<<<<<<< HEAD
            if keys[pygame.K_RIGHT]: dx += 1
            if keys[pygame.K_LEFT]:  dx -= 1  # Fixed typo from K_LEFT if needed
            if keys[pygame.K_LEFT]:  dx -= 1
            if keys[pygame.K_UP]:    dy -= 1
            if keys[pygame.K_DOWN]:  dy += 1
            player.move(dx, dy)

            # Handle Attacks for all living enemies
            for e in enemies:
                if e.health.current > 0:
                    player.handle_attacks(keys, e)
                    e.chase(player)

        # 3. Drawing
        # Always draw the player
        player.draw_self(screen)
        player.draw_stamina_bar(screen)
        player.draw_health_bar(screen)

        # Draw all enemies
        for e in enemies:
            if e.health.current > 0:
                e.draw_self(screen)
                e.draw_health_bar(screen)

        if game_over:
            # Simple Game Over text
            font = pygame.font.SysFont(None, 74)
            text = font.render('GAME OVER', True, RED)
            screen.blit(text, (WIDTH // 2 - 150, HEIGHT // 2))

=======

            if keys[pygame.K_RIGHT]:
                dx += 1
            if keys[pygame.K_LEFT]:
                dx -= 1
            if keys[pygame.K_UP]:
                dy -= 1
            if keys[pygame.K_DOWN]:
                dy += 1

            # if keys[pygame.K_SPACE]:
            # player.attacks[0].perform[player, enemy]

            player.move(dx, dy)


        player.draw_self(screen)
        player.draw_stamina_bar(screen)
        player.draw_health_bar(screen)
        enemy.draw_self(screen)
        enemy.draw_health_bar(screen)
        enemy.chase(player)
>>>>>>> origin/master
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()


if __name__ == "__main__":
<<<<<<< HEAD
    main()
=======
    main()
>>>>>>> origin/master
